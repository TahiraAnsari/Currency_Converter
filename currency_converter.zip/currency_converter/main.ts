import inquirer from "inquirer";

//Data of Currency
const currency: any = {
    USD: 1, //base currency 1$
    EUR: 0.91, //1$ equals to 0.91
    GBR: 0.76, //1$ equals to 0.76
    INR: 74.57, //1$ equals to 74.57
    PKR: 280 //1$ equals to 289
}
let userAnsawer = await inquirer.prompt(
    [
        {
            name: "from",
            message: "Enter From Currency:",
            type: "list",
            choices: ["USD", "EUR", "GBP", "INR", "PKR"] 
        },

        {
            name: "to",
            message: "Enter To Currency:",
            type: "list",
            choices: ["USD", "EUR", "GBP", "INR", "PKR"] 
        },

        {
            name: "amount",
            message: "Enter your Amount:",
            type: "number",
        }
]
);

let fromAmount = currency[userAnsawer.from]
let toAmount = currency[userAnsawer.to]
let amount = userAnsawer.amount
let baseAmount = amount / fromAmount //USD $ Base Currency
let convertedAmount = baseAmount * toAmount
let roundOffCurrency  = convertedAmount.toFixed(1)
console.log(`${userAnsawer.from} Currency Converted into ${userAnsawer.to} Currency`);
console.log(`Amount: ${amount}`);
console.log(`Converted Currency: ${roundOffCurrency}`);
